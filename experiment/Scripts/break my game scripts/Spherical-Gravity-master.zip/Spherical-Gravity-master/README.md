# Spherical-Gravity
Source code from my spherical gravity tutorial, updated for Unity 5. 
Tutorial availaible here: https://youtu.be/TicipSVT-T8

Your planet object should have the GravityAttractor script attached. It should also have a 'Planet' tag applied, and a layer specified for the ground. This ground layer should be assigned to the grounded mask on the first person character controller.
